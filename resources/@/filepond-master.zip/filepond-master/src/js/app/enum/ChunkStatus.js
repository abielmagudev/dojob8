export const ChunkStatus = {
	QUEUED: 0,
	COMPLETE: 1,
	PROCESSING: 2,
	ERROR: 3,
	WAITING: 4
};