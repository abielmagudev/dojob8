# Uppy Markdown Editor

This example uses Uppy to handle images in a markdown editor.

## Run it

To run this example, make sure you've correctly installed the **repository root**:

```sh
corepack yarn install
corepack yarn build
```

That will also install the dependencies for this example.

Then, again in the **repository root**, start this example by doing:

```sh
corepack yarn workspace @uppy-example/transloadit-markdown-bin start
```