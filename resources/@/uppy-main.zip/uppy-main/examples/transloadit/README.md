# Transloadit example

This example shows how to make advantage of Uppy API to upload files to
[Transloadit](https://transloadit.com/).

## Run it

To run this example, make sure you've correctly installed the **repository root**:

```sh
corepack yarn install
corepack yarn build
```

That will also install the dependencies for this example.

Then, again in the **repository root**, start this example by doing:

```sh
corepack yarn workspace @uppy-example/transloadit start
```
