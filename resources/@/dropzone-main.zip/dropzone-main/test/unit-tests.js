import "./unit-tests/all";
import "./unit-tests/amazon-s3";
import "./unit-tests/emitter";
import "./unit-tests/static-functions";
