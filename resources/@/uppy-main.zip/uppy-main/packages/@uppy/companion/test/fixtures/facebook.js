const defaults = require('./constants')

module.exports.expects = {
  listPath: 'ALBUM-ID',
  itemName: `${defaults.ITEM_ID} 2015-07-17T17:26:50+0000`,
  itemMimeType: 'image/jpeg',
  itemSize: null,
}
