# CDN example

To run the example, open the `index.html` file in your browser.

If you want to spawn a local webserver, you can use the following commands
(requires Deno, Python, or PHP):

```sh
corepack yarn install
corepack yarn workspace @uppy-example/cdn dev
```
