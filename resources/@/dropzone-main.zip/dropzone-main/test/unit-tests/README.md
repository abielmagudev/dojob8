Initially all tests were just written in `all.js` but this file has become
quite difficult to maintain.

The idea is to have one file per feature now, which makes it a lot easier to
manage. Not all groups have been extracted from `all.js` yet though, but please
don't add any more to that file.
