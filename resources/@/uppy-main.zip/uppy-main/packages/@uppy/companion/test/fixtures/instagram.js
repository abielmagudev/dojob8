module.exports.expects = {
  itemName: 'Instagram 2017-08-31T18:10:00+00000.jpeg',
  itemMimeType: 'image/jpeg',
  itemSize: null,
}
