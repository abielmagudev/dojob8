# Security Policy

## Reporting a Vulnerability

General security issues and concerns are we welcome in the public Github issue tracker: https://github.com/transloadit/uppy/issues.

In case of a high risk of the shared vulnerability being exploited, please report it to support@transloadit.com instead, and visit https://transloadit.com/security/ to read about Transloadit’s security policy, and how we generally handle these cases.
