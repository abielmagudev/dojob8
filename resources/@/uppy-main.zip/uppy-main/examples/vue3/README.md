# Vue 3 example

To run the example, from the root directory of this repo, run the following commands:

```sh
cp .env.example .env
corepack yarn install
corepack yarn build
corepack yarn workspace @uppy-example/vue3 dev
```
