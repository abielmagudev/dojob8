export default {
  strings: {
    // Shown in the Status Bar
    compressingImages: 'Compressing images...',
    compressedX: 'Saved %{size} by compressing images',
  },
}
