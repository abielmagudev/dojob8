# Uppy with Svelte

## Run it

To run this example, make sure you've correctly installed the **repository root**:

```sh
corepack yarn install
corepack yarn build
```

Then, again in the **repository root**, start this example by doing:

```sh
corepack yarn workspace @uppy-example/svelte-app start
```
