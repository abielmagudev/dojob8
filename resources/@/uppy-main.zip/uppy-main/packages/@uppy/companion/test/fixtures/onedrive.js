const defaults = require('./constants')

module.exports.expects = {
  itemRequestPath: `${defaults.ITEM_ID}?driveId=DUMMY-DRIVE-ID`,
}
