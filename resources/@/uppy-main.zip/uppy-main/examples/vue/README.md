# Vue 2 example

You’re browsing the documentation for Vue v2.x and earlier. Check out
[Vue 3 example](../vue3/) for new projects.

To run the example, from the root directory of this repo, run the following commands:

```sh
corepack yarn install
corepack yarn build
corepack yarn workspace @uppy-example/vue2 dev
```
