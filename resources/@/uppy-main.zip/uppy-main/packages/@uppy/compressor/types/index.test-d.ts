import Uppy from '@uppy/core'
import Compressor from '..'

{
  const uppy = new Uppy()
  uppy.use(Compressor)
}
