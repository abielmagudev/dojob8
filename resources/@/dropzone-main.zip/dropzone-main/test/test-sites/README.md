These sites serve as examples, and are tested with Cypress.

The tests are in `/cypress/integration`.
