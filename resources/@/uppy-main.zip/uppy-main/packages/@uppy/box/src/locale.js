export default {
  strings: {
    pluginNameBox: 'Box',
  },
}
