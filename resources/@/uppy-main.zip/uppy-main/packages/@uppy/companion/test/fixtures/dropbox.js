module.exports.expects = {
  itemIcon: 'file',
  itemRequestPath: '%2Fhomework%2Fmath%2Fprime_numbers.txt',
}
