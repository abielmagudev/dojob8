module.exports = {
  plugins: [
    // eslint-disable-next-line global-require
    require('postcss-import')(),
  ],
}
