export default  {
  strings: {
    timedOut: 'Upload stalled for %{seconds} seconds, aborting.',
  },
}
