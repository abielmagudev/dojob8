// adding this directive to make sure the output file is using strict mode:

'use strict'

import * as Uppy from './index.mjs'

globalThis.Uppy = Uppy
